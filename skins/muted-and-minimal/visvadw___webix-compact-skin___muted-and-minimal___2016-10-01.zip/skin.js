//[Skin Customization]
webix.skin.compact.barHeight=32;webix.skin.compact.tabbarHeight=32;webix.skin.compact.rowHeight=26;webix.skin.compact.listItemHeight=32;webix.skin.compact.inputHeight=32;webix.skin.compact.layoutMargin.wide=5;webix.skin.compact.layoutMargin.space=5;webix.skin.compact.layoutPadding.space=5;
 webix.skin.set('compact')