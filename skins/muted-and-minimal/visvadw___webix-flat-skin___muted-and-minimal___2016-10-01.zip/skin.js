//[Skin Customization]
webix.skin.flat.barHeight=42;webix.skin.flat.tabbarHeight=42;webix.skin.flat.rowHeight=34;webix.skin.flat.listItemHeight=34;webix.skin.flat.inputHeight=38;webix.skin.flat.layoutMargin.wide=10;webix.skin.flat.layoutMargin.space=10;webix.skin.flat.layoutPadding.space=10;
 webix.skin.set('flat')