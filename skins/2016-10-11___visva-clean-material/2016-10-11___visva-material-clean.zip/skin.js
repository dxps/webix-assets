//[Skin Customization]
webix.skin.material.barHeight=32;webix.skin.material.tabbarHeight=32;webix.skin.material.rowHeight=32;webix.skin.material.listItemHeight=32;webix.skin.material.inputHeight=32;webix.skin.material.layoutMargin.wide=10;webix.skin.material.layoutMargin.space=10;webix.skin.material.layoutPadding.space=10;
 webix.skin.set('material')